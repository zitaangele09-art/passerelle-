// Base de données : PostgreSQL si DATABASE_URL est défini (production), sinon SQLite intégrée à Node 22.5+ (essais en local, tests).
// Toutes les fonctions sont asynchrones et identiques dans les deux modes.
//   D.get / D.all / D.run (sql avec ?), D.tx(async c => ...) avec c.get / c.all / c.run / c.balance / c.lockUser
// Avec PostgreSQL, les comptes et les soldes survivent aux redémarrages et aux redéploiements : ils ne sont plus sur le disque du serveur.
const fs = require('fs');
const path = require('path');

const URL_PG = process.env.DATABASE_URL || '';
const PG = !!URL_PG;
const FILE = process.env.DB_PATH || './passerelle.db';

// Montants stockés en entiers (plus petite unité) : jamais de virgule flottante pour l'argent.
const ZERO = new Set(['XOF', 'XAF', 'JPY', 'KRW', 'UGX', 'RWF', 'GNF', 'KMF', 'DJF', 'BIF', 'VND', 'CLP', 'PYG']);
const facteur = c => (ZERO.has(c) ? 1 : 100);
const toMinor = (c, x) => Math.round(Number(x) * facteur(c));
const toMajor = (c, m) => m / facteur(c);

// Schéma : mêmes tables dans les deux modes ; seuls les types changent.
const T = PG
  ? { id: 'BIGSERIAL PRIMARY KEY', int: 'BIGINT', real: 'DOUBLE PRECISION' }
  : { id: 'INTEGER PRIMARY KEY', int: 'INTEGER', real: 'REAL' };
const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
    id ${T.id}, phone TEXT UNIQUE NOT NULL, first_name TEXT NOT NULL, last_name TEXT NOT NULL,
    pin_salt TEXT NOT NULL, pin_hash TEXT NOT NULL, pin_fails ${T.int} NOT NULL DEFAULT 0,
    pin_locked_until ${T.int} NOT NULL DEFAULT 0, kyc TEXT NOT NULL DEFAULT 'none', created_at ${T.int} NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS otps (
    phone TEXT PRIMARY KEY, code_hash TEXT NOT NULL, expires ${T.int} NOT NULL,
    attempts ${T.int} NOT NULL DEFAULT 0, sent_at ${T.int} NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY, user_id ${T.int} NOT NULL REFERENCES users(id), expires ${T.int} NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS ops (
    id ${T.id}, ref TEXT UNIQUE NOT NULL, user_id ${T.int} NOT NULL REFERENCES users(id),
    type TEXT NOT NULL, status TEXT NOT NULL, currency TEXT NOT NULL, to_currency TEXT,
    amount ${T.int} NOT NULL, fee ${T.int} NOT NULL, received ${T.int}, eur ${T.real} NOT NULL DEFAULT 0,
    country TEXT, method TEXT, name TEXT, account TEXT, provider_ref TEXT, reason TEXT, idem TEXT,
    created_at ${T.int} NOT NULL, UNIQUE (user_id, idem))`,
  // Registre des soldes : on n'écrit jamais de solde, seulement des mouvements. Le solde = la somme des mouvements.
  `CREATE TABLE IF NOT EXISTS ledger (
    id ${T.id}, user_id ${T.int} NOT NULL REFERENCES users(id), currency TEXT NOT NULL,
    amount ${T.int} NOT NULL, kind TEXT NOT NULL, op_ref TEXT, created_at ${T.int} NOT NULL,
    UNIQUE (op_ref, kind))`,
  `CREATE TABLE IF NOT EXISTS assistant_usage (user_id ${T.int} NOT NULL, day TEXT NOT NULL, n ${T.int} NOT NULL DEFAULT 0, PRIMARY KEY (user_id, day))`,
  'CREATE INDEX IF NOT EXISTS ledger_user ON ledger (user_id, currency)',
  'CREATE INDEX IF NOT EXISTS ops_user ON ops (user_id, id)',
];

// Fonctions communes (solde, verrou) construites au-dessus de get/all/run
function enrichir(base, lockUser) {
  return Object.assign(base, {
    lockUser,
    balance: async (uid, cur) => (await base.get('SELECT COALESCE(SUM(amount),0) AS s FROM ledger WHERE user_id=? AND currency=?', [uid, cur])).s,
    balances: async uid => {
      const o = {};
      for (const r of await base.all('SELECT currency, SUM(amount) AS s FROM ledger WHERE user_id=? GROUP BY currency', [uid])) o[r.currency] = r.s;
      return o;
    },
  });
}

let D;
if (PG) {
  // ---------------------------------------------------------------- PostgreSQL
  const pg = require('pg');
  pg.types.setTypeParser(20, Number);        // BIGINT  -> nombre (montants, dates en ms : bien en dessous de 2^53)
  pg.types.setTypeParser(1700, parseFloat);  // NUMERIC (résultat de SUM) -> nombre
  const sslVoulu = process.env.PGSSL === 'require' || (/\.(render\.com|supabase\.(com|co))/.test(URL_PG) && !/sslmode=/.test(URL_PG));
  const pool = new pg.Pool({
    connectionString: URL_PG, max: Number(process.env.PG_POOL_MAX) || 10,
    ssl: process.env.PGSSL === 'disable' ? false : (sslVoulu ? { rejectUnauthorized: false } : undefined),
  });
  pool.on('error', e => console.error('[PG] connexion inactive perdue :', e.message));
  const num = sql => { let i = 0; return sql.replace(/\?/g, () => '$' + (++i)); };   // ? -> $1, $2…
  const sur = ex => enrichir({
    get: async (sql, p = []) => (await ex.query(num(sql), p)).rows[0],
    all: async (sql, p = []) => (await ex.query(num(sql), p)).rows,
    run: async (sql, p = []) => { await ex.query(num(sql), p); },
  }, async uid => { await ex.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [uid]); });   // verrou de ligne : deux envois simultanés d'un même client passent l'un après l'autre
  D = sur(pool);
  D.kind = 'postgres';
  D.label = 'PostgreSQL';
  D.init = async () => { for (const s of SCHEMA) await pool.query(s); };
  D.tx = async fn => {
    const cl = await pool.connect();
    try {
      await cl.query('BEGIN');
      const r = await fn(sur(cl));
      await cl.query('COMMIT');
      return r;
    } catch (e) { try { await cl.query('ROLLBACK'); } catch (_) {} throw e; }
    finally { cl.release(); }
  };
  D.sauvegarder = null;   // les sauvegardes sont faites par le service PostgreSQL (voir README)
  D.close = () => pool.end();
} else {
  // ---------------------------------------------------------------- SQLite
  const { DatabaseSync } = require('node:sqlite');
  fs.mkdirSync(path.dirname(path.resolve(FILE)), { recursive: true });
  const sdb = new DatabaseSync(FILE);
  sdb.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
  // Une seule connexion : toutes les opérations passent dans une file, et une transaction garde la file jusqu'à son COMMIT.
  let file = Promise.resolve();
  const enFile = fn => { const p = file.then(fn, fn); file = p.catch(() => {}); return p; };
  const direct = enrichir({
    get: async (sql, p = []) => sdb.prepare(sql).get(...p),
    all: async (sql, p = []) => sdb.prepare(sql).all(...p),
    run: async (sql, p = []) => { sdb.prepare(sql).run(...p); },
  }, async () => {});   // BEGIN IMMEDIATE verrouille déjà tout
  D = enrichir({
    get: (sql, p) => enFile(() => direct.get(sql, p)),
    all: (sql, p) => enFile(() => direct.all(sql, p)),
    run: (sql, p) => enFile(() => direct.run(sql, p)),
  }, async () => {});
  D.kind = 'sqlite';
  D.label = 'SQLite ' + path.resolve(FILE);
  D.init = async () => { for (const s of SCHEMA) sdb.exec(s); };
  D.tx = fn => enFile(async () => {
    sdb.exec('BEGIN IMMEDIATE');
    try { const r = await fn(direct); sdb.exec('COMMIT'); return r; }
    catch (e) { try { sdb.exec('ROLLBACK'); } catch (_) {} throw e; }
  });
  // Copie cohérente de la base (même pendant que le serveur travaille). On garde les `garder` dernières.
  D.sauvegarder = (dossier, garder = 14) => enFile(async () => {
    fs.mkdirSync(dossier, { recursive: true });
    const nom = path.join(dossier, 'passerelle-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db');
    sdb.exec("VACUUM INTO '" + nom.replace(/'/g, "''") + "'");
    const anciens = fs.readdirSync(dossier).filter(f => /^passerelle-.*\.db$/.test(f)).sort();
    while (anciens.length > garder) fs.unlinkSync(path.join(dossier, anciens.shift()));
    return nom;
  });
  D.close = async () => sdb.close();
}
D.toMinor = toMinor; D.toMajor = toMajor; D.FILE = FILE;
module.exports = D;
