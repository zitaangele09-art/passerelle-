# Passerelle v2 — comptes, registre des soldes, base de données (MODE TEST)

Aucun argent réel ne bouge : le prestataire de paiement est un simulateur (`sandbox.js`).

## Ce qui est inclus
- **Comptes** : inscription avec prénom, nom, numéro de téléphone, code reçu par SMS, puis code PIN à 4 chiffres.
- **Registre des soldes** : on n'écrit jamais un solde, seulement des mouvements (dépôt, débit d'envoi, remboursement…). Le solde est leur somme. Un même mouvement ne peut pas être écrit deux fois, et le solde ne peut pas passer sous zéro (testé avec 30 envois simultanés).
- **Base de données** : PostgreSQL en production (variable `DATABASE_URL`) ; sans cette variable, SQLite intégrée à Node (fichier `passerelle.db`, ou `DB_PATH`) pour les essais en local et les tests.
- **Sécurité** : PIN haché (scrypt), 5 mauvais PIN = compte verrouillé 15 min, codes SMS valables 5 min et 5 essais, clés d'idempotence (pas de doublon si on retouche le bouton), limitation du nombre de requêtes, jetons de session stockés hachés, plafonds par jour et par mois côté serveur.
- **Taux en direct** (parités fixes, BCE, marché) et **suivi des opérations** (en cours, reçu, refusé, avec remboursement).

## Lancer et tester
`npm start` puis http://localhost:3000   —   `npm test` lance 40 tests automatiques (comptes, registre, sauvegardes, SMS, assistant IA).
Render : Build `npm install`, Start `npm start` (Node 22.5 ou plus). `npm install` est maintenant nécessaire (paquet `pg`).

## Avant de passer en réel (à ne pas sauter)
1. **SMS** : sans la variable `SMS_PROVIDER`, le code est affiché à l'écran (mode test). Branchez un prestataire SMS dans `sms.js`, puis définissez `SMS_PROVIDER`.
2. **Persistance** : définissez `DATABASE_URL` (voir la section PostgreSQL ci-dessous). Sans elle, la base SQLite est sur le disque du serveur, effacé à chaque redémarrage sur l'offre gratuite de Render.
3. **PIN** : 4 chiffres, c'est faible si la base fuit. Définissez `PIN_PEPPER` (texte secret long, variable d'environnement) et envisagez un PIN à 6 chiffres.
4. **Partenaire de paiement agréé** : remplacez `sandbox.js` (voir `template.js`) : `send`, `cashIn`, `cashOut`, `status`.
5. **Vérification d'identité (KYC)** : champ `kyc` prévu dans la base, mais aucune vérification n'est faite.
6. **Aspects légaux** : agrément, lutte anti-blanchiment, protection des données personnelles. À valider avec un professionnel.


## Base PostgreSQL sur Render (recommandé : les comptes ne disparaissent plus)
1. Render → **New** → **PostgreSQL** (choisir la même région que le service web). Le plan gratuit de Render expire après 30 jours : prenez un plan payant pour de vrais comptes (vérifier sur render.com/pricing).
2. Dans la base créée, copiez l'**Internal Database URL**.
3. Service web → **Environment** → ajouter `DATABASE_URL` = cette adresse, plus `PIN_PEPPER` (long texte secret, défini AVANT de créer des comptes et jamais changé ensuite).
4. Enregistrer : Render redéploie. Les tables sont créées automatiquement au démarrage.
- Plusieurs instances du serveur sont possibles avec PostgreSQL (le disque persistant n'est plus nécessaire). `DB_PATH` et les sauvegardes de fichiers ne servent qu'en mode SQLite.
- Sauvegardes : à activer côté Render PostgreSQL (plans payants).
- Si la connexion est refusée en SSL : `PGSSL=require` (forcer) ou `PGSSL=disable` (désactiver).
- Les comptes déjà créés dans SQLite ne sont pas repris automatiquement.

## Base PostgreSQL sur Supabase (alternative à Render PostgreSQL)
1. Supabase → votre projet → **Connect** → case **Direct** (Connection string) → type **Session pooler**.
2. Copiez l'adresse `postgresql://…`, remplacez `[YOUR-PASSWORD]` par le mot de passe de la base (évitez `@ / #` dans ce mot de passe).
3. Dans l'hébergeur du serveur, variables : `DATABASE_URL` (cette adresse), `PGSSL=require`, `PIN_PEPPER` (secret long, jamais changé).
4. Au démarrage les tables se créent seules : vérifiez-les dans **Table Editor**.
- Ne mettez jamais le mot de passe de la base dans GitHub : uniquement dans les variables d'environnement.

## (Ancienne option) Disque persistant Render avec SQLite
Le plan gratuit efface le disque à chaque redémarrage. Un disque persistant n'existe que sur un service payant.
1. Service → **Settings** → **Instance Type** → **Starter** (environ 7 $/mois, à vérifier sur render.com/pricing).
2. Service → **Disks** → **Add Disk** : nom `data`, **Mount Path** `/var/data`, taille 1 Go (environ 0,25 $/Go/mois).
3. Service → **Environment** → ajouter :
   - `DB_PATH` = `/var/data/passerelle.db`
   - `PIN_PEPPER` = un long texte secret de votre choix (à définir AVANT de créer des comptes, et à ne jamais changer ensuite)
4. Enregistrer : Render redéploie. À chaque redéploiement, le service est indisponible quelques secondes (limite d'un service avec disque).
Sauvegardes : le serveur copie la base chaque jour dans `/var/data/backups` (14 copies gardées), et Render prend aussi un instantané quotidien du disque. Un disque ne permet pas d'avoir plusieurs instances.

## SMS réel avec Twilio
Variables à ajouter dans Render (Environment) :
- `SMS_PROVIDER` = `twilio`
- `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` (depuis la console Twilio)
- `SMS_FROM` = nom d'expéditeur (3 à 11 lettres/chiffres, ex. `Passerelle`) ou numéro Twilio
Dès que `SMS_PROVIDER` est défini, le code n'est plus affiché à l'écran.
Attention : au Bénin, un nom d'expéditeur doit être enregistré (pièces d'entreprise, délais). Au Sénégal, l'enregistrement auprès de Twilio est demandé pour Orange et Expresso (règle annoncée à partir du 8 septembre 2026). Vérifiez les règles de Twilio pour chaque pays avant de lancer.

## Assistant intégré (bouton « ? »)
Deux niveaux :
1. **Sans clé** : assistant à règles, gratuit, qui répond sur les frais (avec calcul), délais, plafonds, soldes, taux, dépôt, retrait, statut du dernier envoi, PIN oublié, sécurité.
2. **Avec Claude** : définissez `ANTHROPIC_API_KEY` dans Render (clé créée sur console.anthropic.com, compte avec facturation). L'assistant devient une IA qui répond librement, mais toujours à partir des règles de l'application (frais, plafonds, délais, taux) et du contexte de l'utilisateur. Si Claude ne répond pas, l'assistant à règles prend le relais.
- Variables facultatives : `ASSISTANT_MODEL` (défaut `claude-haiku-5-5`), `ASSISTANT_DAILY_MAX` (questions par utilisateur et par jour, défaut 50).
- L'IA ne peut effectuer aucune opération et ne voit jamais le PIN, les codes SMS, le téléphone ni les numéros de compte. Elle reçoit : le prénom, les soldes, les plafonds utilisés, les 5 dernières opérations (type, montant, statut, référence, prénom du bénéficiaire) et les messages de la conversation.
- Ces données sont envoyées à Anthropic pour produire la réponse : à mentionner dans votre politique de confidentialité et à faire valider par un juriste.
- La clé ne doit JAMAIS être mise dans GitHub : uniquement dans Environment (Render).
