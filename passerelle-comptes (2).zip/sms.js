// Envoi des codes par SMS.
//
// Sans variable SMS_PROVIDER : mode TEST. Le code est écrit dans les journaux ET renvoyé à
// l'application (« devCode ») pour pouvoir essayer sans SMS. À ne jamais laisser ainsi avec de vrais clients.
//
// SMS_PROVIDER=twilio : envoi réel avec Twilio. Variables à définir dans Render (jamais dans le code) :
//   TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN
//   SMS_FROM  = nom d'expéditeur alphanumérique (3 à 11 caractères, ex. « Passerelle ») ou numéro Twilio
//   (ou TWILIO_MESSAGING_SERVICE_SID à la place de SMS_FROM)
// Attention : au Sénégal et au Bénin, un nom d'expéditeur alphanumérique doit être enregistré
// auprès de Twilio (délais et pièces d'entreprise demandés). Sans cela, les SMS peuvent ne pas arriver.
//
// Pour un autre prestataire, ajoutez un bloc « if (p === ... ) » sur le même modèle.
module.exports = {
  async send(phone, text) {
    const p = process.env.SMS_PROVIDER;
    if (!p) { console.log('[SMS test]', phone, text); return { devCode: true }; }
    if (p === 'twilio') {
      const sid = process.env.TWILIO_ACCOUNT_SID, tok = process.env.TWILIO_AUTH_TOKEN;
      const from = process.env.SMS_FROM, svc = process.env.TWILIO_MESSAGING_SERVICE_SID;
      if (!sid || !tok || !(from || svc)) throw new Error('Twilio : TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN et SMS_FROM (ou TWILIO_MESSAGING_SERVICE_SID) sont requis');
      const body = new URLSearchParams({ To: phone, Body: text });
      if (svc) body.set('MessagingServiceSid', svc); else body.set('From', from);
      const r = await fetch('https://api.twilio.com/2010-04-01/Accounts/' + encodeURIComponent(sid) + '/Messages.json', {
        method: 'POST',
        headers: { Authorization: 'Basic ' + Buffer.from(sid + ':' + tok).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' },
        body
      });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error('Twilio ' + r.status + ' ' + (j.code || '') + ' ' + (j.message || '')); }
      return {};
    }
    throw new Error('Prestataire SMS « ' + p + ' » non géré dans sms.js');
  }
};
